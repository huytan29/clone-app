### Changelog

## Version 1.0.0 (17 January 2019)

## Version 1.2.3 (19 May 2021)

- Added mapbox-gl plugin
- Alert Dismissing issue resolved
- Card image issue resolved
- Fontawesome icon issue resolved

## Version 2.0.0 (07 Sep 2021)

- Migrating to Bootstrap v5

## Version 3.0.0 (05 April 2021)

- Migrating to WebPack v5

## Version 3.1.0 (22 Aug 2022)

- Library Update